to use this bot you should to download python 2.7.14
and type this commands on your cmd to run the code :
1.pip install requests
2.pip install threading
3.pip install mechanize
4.pip install colorama
5.pip install McScrp

#This tool by X-Warning
Blog: www.x-warning.com
Facebook: www.facebook.com/Warning.Siyass
ICQ: 744732242
Youtube Channel: https://www.youtube.com/channel/UCm_9cc0ZCtqrr3KtRwWSsGQ
My Email: warningsiyass@gmail.com
#This is just V0.1 ;) 

